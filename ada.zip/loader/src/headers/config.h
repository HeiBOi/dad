#pragma once

#define HTTP_SERVER "88.99.185.224"
#define HTTP_PORT 80

#define TFTP_SERVER "88.99.185.224"
